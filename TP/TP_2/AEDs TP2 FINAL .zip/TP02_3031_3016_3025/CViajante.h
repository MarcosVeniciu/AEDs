#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* 
 * Foi Criada a struct para armazenar os valores da menor distância, e o caminho
 * que foi percorido
 */
typedef struct{
    int menorD;
    int *vetor;
    int PrimeiraDistancia;
}TMenor;


int InicialilizarStruct(TMenor* pMenor, int Cidades);
int menorDistancia(TMenor* pMenor);
int* melhorCaminho(TMenor* pMenor);

//Inserir valor matricula
int InsereESomaValorMatricula(int numero_Cidades);

//Inicializar, Inserir e Imprimir Matriz
int** InicializarMatriz(int Linhas, int Colunas);
int** setValorMatriz(int **M,int Linhas,int Colunas);
int ImprimeMatriz(int **M,int Linhas,int Colunas);


//Permutacao
void permuta(int* vetor, int inf, int sup,int cidade_Inicial, int **M,TMenor* pMenor);
void troca(int vetor[], int i, int j);
int* InicializarVetorNumeros(int numero_Cidades);
int* ValoresParaPermutacao(int* vetor,int numero_Cidades,int cidade_Inicial);