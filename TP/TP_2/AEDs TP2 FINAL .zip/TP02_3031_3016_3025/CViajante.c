#include "CViajante.h"

/*
  > A função InicialilizarStruct irá atribuir valores iniciais para as variaveis para evitar 
  lixo de memoria.
  > Tambem irá alocar um vetor para armazenar o numero das cidades das sequências percorridas e 
   atribuir zero para evitar lixo de memoria.
*/
int InicialilizarStruct(TMenor* pMenor, int Cidades){
    int i;
    pMenor->menorD= 0;

    pMenor->PrimeiraDistancia = 0;

    pMenor->vetor= (int*) malloc(Cidades * sizeof(int));
    for(i=0;i<Cidades;i++){
        pMenor->vetor[i]= 0;
    }
    return 0;
}
/*
  > InicializarMatriz: Aloca uma matriz N_cidade x N_cidade e inicializa ela com zeros.
  > Primeiro ela aloca um vetor para o numero de linhas e depois percorre essse vetor alocando 
  para cada indice um outro vetor como colunas de tamanho N_cidades.
  > Em seguida ele percorre o vetor de colunas inicializando cada indice com zero.
  > Retorna o endereço dessa matriz.
*/
int** InicializarMatriz(int Linhas, int Colunas){
    int i,j;
    int **M = (int**)malloc(Linhas * sizeof(int*)); //Aloca um Vetor de Ponteiros

    for (i = 0; i < Linhas; i++){ //Percorre as linhas do Vetor de Ponteiros
        M[i] = (int*) malloc(Colunas * sizeof(int)); //Aloca um Vetor de Inteiros para cada posição do Vetor de Ponteiros.
        for (j = 0; j < Colunas; j++){ //Percorre o Vetor de Inteiros atual.
            M[i][j]= 0;
         }
    }
  return M;
}

/*
  >setValorMatriz é a função que ira preencher a matriz, caso os indices i e j sejam iguais esse 
  indice recebe zero,caso contrario será atribuido um numero gerado aleatoriamente.
*/
int** setValorMatriz(int **M,int Linhas,int Colunas){
    int i,j;
    for (i = 0; i < Linhas; i++){ //Percorre as linhas do Vetor de Ponteiros
        for (j = 0; j < Colunas; j++){ //Percorre o Vetor de Inteiros atual.
            if(i == j){
                M[i][j]= 0 ;
            }else{
                M[i][j] = 1 +(rand() % 99);
          }
        }
    }
    return M;
}

int ImprimeMatriz(int **M,int Linhas,int Colunas){
    int i,j;

    for(i=0;i<Linhas;i++){
        for(j=0;j<Colunas;j++){
            if (M[i][j]<10) {
              printf("%d  ",M[i][j]);
            } else {
              printf("%d ",M[i][j]);
            }
        }
        printf("\n");
    }
    return 0;
}
/*
  > InsereESomaValorMatricula irá definir a cidade onde se iniciará o percurso.
  > irá somar os numeros das matriculas, e calcular o resto da divisão da soma pelo numero de cidades
    e usa-lo como cidade inicial.
*/
int InsereESomaValorMatricula(int numero_Cidades){
    int i,soma =0,conta =0,cidade_inicial =0,matricula;

     printf("==============================================================================\n");
    for(i=0; i<3; i++){
       printf("|| Matricula [%d] ", i+1);
       scanf("%d", &matricula);
       conta = matricula / 100;
       conta = conta / 10;
       soma = soma+conta;
       conta = matricula/100;
       conta = conta % 10;
       soma = soma+conta;
       conta = matricula % 100;
       conta = conta / 10;
       soma = soma + conta;
       conta = matricula % 100;
       conta = conta %10;
       soma = soma + conta;
    }
    printf("==============================================================================\n");

    cidade_inicial = soma % numero_Cidades;

    if(cidade_inicial ==0){
        cidade_inicial = 1;
    }
    return cidade_inicial;
}

/*
  InicializarVetorNumeros irá alocar um vetor do tamanho do numero de cidades para armazernar o numero das Cidades
  e depois inicializa eles com zero para evitar lixo de memoria
*/
int* InicializarVetorNumeros(int numero_Cidades){
    int *v =NULL,i;

    v = (int*)malloc(numero_Cidades*sizeof(int));

    for(i= 0;i<numero_Cidades;i++){
        v[i] = 0;
    }
    return v;
}
/*
  organiza o vetor com os numeros das cidades exeto o da cidade inicial e retorna esse vetor.
*/
int* ValoresParaPermutacao(int* vetor,int numero_Cidades,int cidade_Inicial){
    int i,z =0,x=1;

    for ( i = 0; i < numero_Cidades; i++) {
            if(x!=cidade_Inicial){
               vetor[z]= x;
               z++;
            }
            x++;
        }
    return vetor;// vetor contendo o numero das cidades [cidade_1, cidade_2, cidade_3]
}

void troca(int vetor[], int i, int j){
    int aux = vetor[i];
    vetor[i] = vetor[j];
    vetor[j] = aux;
}
/*
>permuta: Essa funcao tem por objetivo realizar a permutação dos valores requeridos.
@param vetor - Recebe como parametro o vetor que contém os valores a serem permutados.
@param inf - Recebe como parametro o limite inferior, do indice do vetor.
@param sup - Recebe como parametro o limite superior, do indice do vetor.
@param cidade_inicial - Foi retirado da permutacao o valor da cidade_inicial, essa sendo recebida
pela função para manuseio e calculos.
@param **M - Recebe como parametro uma matriz, que foi criada e inicializada anteriormente,
que contem os valores das distancias.
@param pMenor -Recebe como parametro um ponteiro para struct que contém os valores para comparacao.
*/
void permuta(int* vetor, int inf, int sup,int cidade_Inicial, int **M,TMenor *pMenor){
    int soma = 0, i;
    if(inf == sup){
         printf("%d ",cidade_Inicial);
        /*
         * Esse For é responsavel por inserir de forma ordenada os termos da permutacao.É inserido uma sequencia por vez, sendo
         * que abaixo o programa retorna para mesma funcao e assim o processo de repete ate a concretizacao das repeticoes.
         * A cada loop do for, é inserido um numero, esse numero sera avaliado pelos comandos if e else if, e conforme a avaliação
         * são utilizados para localizar a sua posicao na matriz criada anteriormente e assim e o valor da sua distancia.
         */
        for( i = 0; i <= sup; i++){
                if(i == 0 ){
                    soma = soma +  M[cidade_Inicial-1][vetor[i]-1];
                }
                else if (i == sup ){
                   soma= soma+ M[vetor[i]-1][cidade_Inicial-1];
                   soma= soma+ M[vetor[i-1]-1][vetor[i]-1];
                }
                else if(i<sup){
                    soma= soma+ M[vetor[i-1]-1][vetor[i]-1];
                }
            printf("%d ", vetor[i]);
        }
        if(pMenor->PrimeiraDistancia == 0){
            pMenor->menorD = soma;
            pMenor->PrimeiraDistancia++;
            for(i= 0;i<=sup;i++){
                pMenor->vetor[i]= vetor[i];
            }
        }else{
            if(soma<pMenor->menorD){
                pMenor->menorD = soma;
                for(i= 0;i<=sup;i++){
                    pMenor->vetor[i]= vetor[i];
                }
            }
        }
        printf("%d",cidade_Inicial);
        printf(" -> %d < - Distancia",soma);
        printf("\n");
    }else{
        for(int i = inf; i <= sup; i++){
            troca(vetor, inf, i);
            permuta(vetor, inf + 1, sup,cidade_Inicial,M,pMenor);
            troca(vetor, inf, i); // retrocesso
        }
    }
}
/*
  retorna a menor distancia encontrada.
*/
int menorDistancia(TMenor* pMenor){
    return pMenor->menorD;
}
/*
  retorna a sequencia de cidades com a menor distância
*/
int* melhorCaminho(TMenor* pMenor){
   return pMenor->vetor;
}
