#include "CViajante.h"
int LerArquivo();
int main() {
   int Cidades,**M_inicializada,**M_VInseridos,Cidade_Inicial,*v_inicializado ,*v_VInseridos,tam_v,i,opcao;
   TMenor MenorDistancia;
   clock_t inicioT;
   double tempo_gasto;

   do{
        do {
          #ifdef linux
          system("clear");
          #elif defined WIN32
          system("cls");
          #endif
          printf("==============================================================================\n");
          printf("||                                                                          ||\n");
          printf("|| [0] Sair                                                                 ||\n");
          printf("|| [1] Interativo                                                           ||\n");
          printf("|| [2] Arquivo                                                              ||\n");
          printf("||                                                                          ||\n");
          printf("==============================================================================\n");
          printf("|| Opcao: ");
          scanf("%d", &opcao);
        } while((opcao < 0)||(opcao>2));

        if(opcao == 1){
            #ifdef linux
            system("clear");
            #elif defined WIN32
            system("cls");
            #endif
            printf("==============================================================================\n");
            printf("Digite o valor da quantidade de cidades: \n");
            scanf("%d",&Cidades);
            InicialilizarStruct(&MenorDistancia,Cidades);
            M_inicializada = InicializarMatriz(Cidades,Cidades);
            M_VInseridos = setValorMatriz(M_inicializada, Cidades, Cidades);
            printf("==============================================================================\n");
            Cidade_Inicial = InsereESomaValorMatricula(Cidades);
            printf("==============================================================================\n");
            printf("|| Quantidade de Cidades: %d\n", Cidades);
            printf("==============================================================================\n");
            printf("|| Cidade Inicial: %d\n", Cidade_Inicial);
            printf("==============================================================================\n");
            v_inicializado = InicializarVetorNumeros(Cidades);
            v_VInseridos = ValoresParaPermutacao(v_inicializado,Cidades,Cidade_Inicial);
            tam_v = Cidades - 2;
            inicioT = clock();
            printf("-> Executando...\n");
            permuta(v_VInseridos, 0, tam_v,Cidade_Inicial,M_VInseridos,&MenorDistancia);
            clock_t fim = clock();
            tempo_gasto = (double)(fim - inicioT)/CLOCKS_PER_SEC;
            printf("==============================================================================\n");
            printf("|| Matriz de Distancia                                                      ||\n");
            printf("==============================================================================\n");
            ImprimeMatriz(M_VInseridos,Cidades,Cidades);
            printf("==============================================================================\n");
            printf("|| A menor distancia foi %d                                                 ||\n",menorDistancia(&MenorDistancia));
            printf("==============================================================================\n");

            printf("||Sequencia de cidades percorridas com menor distancia                      ||\n");
            printf("%d ",Cidade_Inicial);
            for(i=0;i<Cidades-1;i++){
                printf("%d ",melhorCaminho(&MenorDistancia)[i]);
            }
            printf("%d\n",Cidade_Inicial);
            printf("==============================================================================\n");
            printf("-> Tempo total gasto: %lf segundos.\n\n", tempo_gasto);
            printf("==============================================================================\n");
            opcao = 0;
        }

        if (opcao == 2){
            printf(">>> ARQUIVO DE ENTRADA <<<\n\n");
            LerArquivo();
            opcao = 0;
            }
    }while(opcao !=0);

    return (EXIT_SUCCESS);
}

int LerArquivo(){
    FILE *ptrArquivo;
    int leitura, i=0, j=0, k=0, **M_inicializada,tam_v,*v_inicializado ,*v_VInseridos;
    int matricula_1, matricula_2, matricula_3, Cidades,Cidade_Inicial;
    clock_t inicioT;
    double tempo_gasto;
    TMenor MenorDistancia;

    ptrArquivo = fopen("entrada.txt", "r");

    if(ptrArquivo == NULL){
        printf("ERRO DE LEITURA");
    }
    if(ptrArquivo){
        if(fscanf(ptrArquivo, "%d", &leitura) != EOF){
            matricula_1 = leitura;
        }
        if(fscanf(ptrArquivo, "%d", &leitura) != EOF){
            matricula_2 = leitura;
        }
        if(fscanf(ptrArquivo, "%d", &leitura) != EOF){
            matricula_3 = leitura;
        }
        if(fscanf(ptrArquivo, "%d", &leitura) != EOF){
            Cidades = leitura;
        }
        InicialilizarStruct(&MenorDistancia,Cidades);
        M_inicializada = InicializarMatriz(Cidades,Cidades);
        for(j=0; j<Cidades; j++){
            for(k=0; k<Cidades; k++){
               if(j==k){
                    M_inicializada[j][k] = 0;
                    }
               else if(fscanf(ptrArquivo, "%d", &leitura) != EOF){
                        M_inicializada[j][k] = leitura;
                }
            }
        }
        printf("\n\n");
        Cidade_Inicial = (matricula_1+ matricula_2 +matricula_3) % Cidades;
        if(Cidade_Inicial == 0){
            Cidade_Inicial = 1;
        }
        v_inicializado = InicializarVetorNumeros(Cidades);
        v_VInseridos = ValoresParaPermutacao(v_inicializado,Cidades,Cidade_Inicial);
        tam_v = Cidades - 2;
        printf("==============================================================================\n");
        printf("Matricula 1 -> %d\n", matricula_1);
        printf("Matricula 2 -> %d\n", matricula_2);
        printf("Matricula 3 -> %d\n", matricula_3);
        printf("==============================================================================\n");
        printf("|| Numero de Cidades: %d\n", Cidades);
        printf("==============================================================================\n");
        printf("|| Cidade Inicial: %d\n", Cidade_Inicial);
        printf("==============================================================================\n");
        inicioT = clock();
        printf("-> Executando...\n");
        permuta(v_VInseridos, 0, tam_v,Cidade_Inicial,M_inicializada,&MenorDistancia);
        clock_t fim = clock();
        tempo_gasto = (double)(fim - inicioT)/CLOCKS_PER_SEC;
        printf("==============================================================================\n");
        printf("|| Matriz de Distancia                                                      ||\n");
        printf("==============================================================================\n");
        ImprimeMatriz(M_inicializada,Cidades,Cidades);
        printf("==============================================================================\n");
        printf("|| A menor distancia foi %d                                                 ||\n",menorDistancia(&MenorDistancia));
        printf("==============================================================================\n");
        printf("||Sequencia de cidades percorridas com menor distancia                      ||\n");
        printf("%d ",Cidade_Inicial);
        for(i=0;i<Cidades-1;i++){
            printf("%d ",melhorCaminho(&MenorDistancia)[i]);
        }
        printf(" %d\n",Cidade_Inicial);
        printf("==============================================================================\n");
        printf("-> Tempo total gasto: %lf segundos.\n\n", tempo_gasto);
        printf("==============================================================================\n");
    }
    fclose(ptrArquivo);
  return 0;
}
